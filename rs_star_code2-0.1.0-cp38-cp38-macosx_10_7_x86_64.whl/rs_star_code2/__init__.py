from .rs_star_code2 import *

__doc__ = rs_star_code2.__doc__
